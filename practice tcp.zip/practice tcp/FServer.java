import java.io.*;
import java.net.*;

public class FServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Server started. Waiting for file...");

            Socket socket = serverSocket.accept();
            System.out.println("Client connected.");

            DataInputStream dis = new DataInputStream(socket.getInputStream());
            FileOutputStream fos = new FileOutputStream("received_file.txt");

            byte[] buffer = new byte[4096];
            int bytesRead;

            // Read until client closes stream
            while ((bytesRead = dis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }

            fos.close();
            dis.close();
            socket.close();
            serverSocket.close();

            System.out.println("File received and saved as received_file.txt");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
